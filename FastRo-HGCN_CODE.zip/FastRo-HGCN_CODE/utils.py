import pickle
import numpy as np
import scipy
import scipy.sparse as sp
import torch
import networkx as nx
import torch.nn.functional as F


def encode_onehot(labels):
    # The classes must be sorted before encoding to enable static class encoding.
    # In other words, make sure the first class always maps to index 0.
    classes = sorted(list(set(labels)))
    classes_dict = {c: np.identity(len(classes))[i, :] for i, c in enumerate(classes)}
    labels_onehot = np.array(list(map(classes_dict.get, labels)), dtype=np.int32)
    return labels_onehot

def normalize_adj(mx):#对称归一化
    """Row-normalize sparse matrix"""
    rowsum = np.array(mx.sum(1))
    r_inv_sqrt = np.power(rowsum, -0.5).flatten()
    r_inv_sqrt[np.isinf(r_inv_sqrt)] = 0.
    r_mat_inv_sqrt = sp.diags(r_inv_sqrt)
    return mx.dot(r_mat_inv_sqrt).transpose().dot(r_mat_inv_sqrt)

def normalize_features(mx):
    """Row-normalize sparse matrix"""
    rowsum = np.array(mx.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(mx)
    return mx


def accuracy(output, labels):
    preds = output.max(1)[1].type_as(labels)
    correct = preds.eq(labels).double()
    correct = correct.sum()
    return correct / len(labels)


def load_ACM_data(prefix='data/ACM_processed'):

    features_0 = scipy.sparse.load_npz(prefix + '/features_0.npz').toarray()
    # features_0 = F.normalize(torch.from_numpy(features_0).type(torch.FloatTensor), dim=1, p=1)
    # features_0 = features_0.numpy()
    features_1 = scipy.sparse.load_npz(prefix + '/features_1.npz').toarray()
    # features_1 = F.normalize(torch.from_numpy(features_1).type(torch.FloatTensor), dim=1, p=1)
    # features_1 = features_1.numpy()
    features_2 = scipy.sparse.load_npz(prefix + '/features_2.npz').toarray()
    # features_2 = F.normalize(torch.from_numpy(features_2).type(torch.FloatTensor), dim=1, p=1)
    # features_2 = features_2.numpy()

    # features_0 = np.array(features_0, dtype=np.float32)
    # features_0 = normalize_features(features_0)
    # features_1 = np.array(features_1, dtype=np.float32)
    # features_1 = normalize_features(features_1)
    # features_2 = np.array(features_2, dtype=np.float32)
    # features_2 = normalize_features(features_2)

    adjM = scipy.sparse.load_npz(prefix + '/adjM.npz').toarray()
    type_mask = np.load(prefix + '/node_types.npy')
    labels = np.load(prefix + '/labels.npy')
    train_val_test_idx = np.load(prefix + '/train_val_test_idx.npz')

    # device = torch.device('cpu')
    # adjM = torch.FloatTensor(adjM).to(device)
    # p_mask = np.where(type_mask == 0)[0]
    # a_mask = np.where(type_mask == 1)[0]
    # s_mask = np.where(type_mask == 2)[0]
    # pap = torch.mm(adjM[p_mask, :][:, a_mask], adjM[a_mask, :][:, p_mask])
    # psp = torch.mm(adjM[p_mask, :][:, s_mask], adjM[s_mask, :][:, p_mask])
    # psp = psp.data.cpu().numpy()
    # pap = pap.data.cpu().numpy()
    # adjM = adjM.data.cpu().numpy()
    # torch.cuda.empty_cache()
    # p_as_p = np.zeros((len(adjM), len(adjM)))
    # for i in range(len(pap)):
    #     for j in range(len(pap)):
    #         if pap[i][j] != 0 and psp[i][j] !=0:
    #             p_as_p[i][j] = 1
    # p_as_p=torch.from_numpy(p_as_p).type(torch.FloatTensor)



    # adjM = adjM
    # adjM = adjM + np.eye(len(adjM))
    # #adjM = scipy.sparse.csr_matrix(adjM)
    # adjM=F.normalize(torch.from_numpy(adjM).type(torch.FloatTensor), dim=1, p=2)
    # adjM = scipy.sparse.csr_matrix(adjM)
    # e=torch.tensor(adjM.data)

    # p_a = np.zeros((len(adj), len(adj)))
    # p_s = np.zeros((len(adj), len(adj)))
    # p_p = np.zeros((len(adj), len(adj)))
    # for i in range(4019):
    #     for j in range(len(adj)):
    #         if adj[i][j] !=0 and j<4019:
    #             p_p[i][j] =1
    #         if adj[i][j] != 0 and j < 11186 and j>=4019:
    #             p_a[i][j] = 1
    #         if adj[i][j] != 0 and j >= 11186:
    #             p_s[i][j] = 1
    # a_p = p_a.T
    # s_p = p_s.T
    # p_p=p_p
    # sp.save_npz('pp_init_single.npz', scipy.sparse.csr_matrix(p_p))
    # daw
    # p_p = normalize_features(scipy.sparse.csr_matrix(p_p)).toarray()
    # a_p = normalize_features(scipy.sparse.csr_matrix(a_p)).toarray()
    # p_a = normalize_features(scipy.sparse.csr_matrix(p_a)).toarray()
    # p_s = normalize_features(scipy.sparse.csr_matrix(p_s)).toarray()
    # s_p = normalize_features(scipy.sparse.csr_matrix(s_p)).toarray()
    #
    # adjM = a_p + p_a + p_s + s_p+p_p
    # adj = scipy.sparse.csr_matrix(adjM)
    # ddd=p_s+s_p


    # p_p = np.zeros((len(adjM), len(adjM)))
    # f=sp.load_npz(prefix + '/PP/pos_acm12.npz').toarray()
    # f=f+f.T
    # f=f-np.eye(len(f))
    # for i in range(len(f)):
    #     for j in range(len(f)):
    #         if j==i:
    #             f[i][j]=0
    #         if f[i][j]!=0:
    #             p_p[i][j]=1
    # p_p = normalize_features(scipy.sparse.csr_matrix(p_p)).toarray()
    #
    # adjM = sp.load_npz('ACM_norm_adj.npz').toarray()
    # a=0
    # for i in range(4019):
    #     for j in range(4019):
    #         if adjM[i][j]!=0:
    #             a=a+1
    # print(a)
    # dwa
    # adjM = adjM + 0.1 * np.eye(len(adjM))#+p_p
    # adjM = F.normalize(torch.from_numpy(adjM).type(torch.FloatTensor), dim=1, p=2)
    # adjM = scipy.sparse.csr_matrix(adjM)
    # e = torch.tensor(adjM.data).type(torch.FloatTensor)


    # p_s_p=sp.load_npz('ps_sp_norm.npz').toarray()
    # pa = np.load(prefix + '/PA/adjm_pa.npy')
    # p_a = np.zeros((len(p_s_p), len(p_s_p)))
    # for i in range(4019):
    #     for j in range(7167):
    #         if pa[i][j]!=0:
    #             p_a[i][j+4019]=1
    # a_p=p_a.T
    # a_p = normalize_features(scipy.sparse.csr_matrix(a_p)).toarray()
    # p_a = normalize_features(scipy.sparse.csr_matrix(p_a)).toarray()
    # adjM = a_p + p_a + p_s_p
    # np.save('acm_adjm_norm_not_pp.npy',adjM)

    adjM = scipy.sparse.load_npz('acm_adjm_norm_not_pp.npz').toarray()
    #adjM=sp.load_npz(prefix + '/acm_add_5_pa/norm_acm_add_5_pa0.npz').toarray()#PA
    #adjM = sp.load_npz(prefix + '/add_ps/norm_acm_add_5_ps4.npz').toarray()#PS
    p_p = np.zeros((len(adjM), len(adjM)))
    #f=sp.load_npz(prefix + '/PP_F_T/pos_acm_only_t8.npz').toarray()
    f = sp.load_npz(prefix + '/PP/pos_acm7.npz').toarray()
    #f = sp.load_npz(prefix + '/PP/pos_acm7_lamda_0.3_.npz').toarray()
    f=f+f.T
    f=f-np.eye(len(f))
    for i in range(len(f)):
        for j in range(len(f)):
            if j==i:
                f[i][j]=0
            if f[i][j]!=0:
                p_p[i][j]=1
    p_p2=sp.load_npz('pp_init_single.npz').toarray()
    p_p=p_p+p_p2
    p_p = normalize_features(scipy.sparse.csr_matrix(p_p)).toarray()
    adjM = adjM + 0.065* np.eye(len(adjM))+p_p
    adjM = F.normalize(torch.from_numpy(adjM).type(torch.FloatTensor), dim=1, p=2)
    adjM = scipy.sparse.csr_matrix(adjM)
    e = torch.tensor(adjM.data).type(torch.FloatTensor)
    # adj=np.zeros((4019,11246))
    # for i in range(4019):
    #     for j in range(11246):
    #         if adjM[i][j]!=0:
    #             adj[i][j]=adjM[i][j]
    # adj = F.normalize(torch.from_numpy(adj).type(torch.FloatTensor), dim=1, p=2)
    # adjM = scipy.sparse.csr_matrix(adj)
    # e = torch.tensor(adjM.data).type(torch.FloatTensor)

    return [features_0, features_1, features_2], adjM, type_mask, labels, train_val_test_idx,e


