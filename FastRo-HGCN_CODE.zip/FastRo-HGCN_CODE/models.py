import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from dgl.nn.pytorch import GraphConv

class FastRo_HGCN(nn.Module):
    def __init__(self, input_dim, l_dim, hidden_dim, layers, num_classes, dropout):
        super(FastRo_HGCN, self).__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.l_dim = l_dim
        self.activation = F.elu
        self.fc_list = nn.ModuleList([nn.Linear(m, l_dim, bias=True) for m in input_dim])
        for fc in self.fc_list:
            nn.init.xavier_normal_(fc.weight, gain=1.414)
        self.hgcn_layers = nn.ModuleList()
        for fc in self.fc_list:
            nn.init.xavier_normal_(fc.weight, gain=1.414)

        self.hgcn_layers.append(GraphConv(l_dim, hidden_dim, activation=self.activation, weight=True))
        for i in range(layers - 1):
            self.hgcn_layers.append(GraphConv(hidden_dim, hidden_dim, activation=self.activation, weight=True))
        self.hgcn_layers.append(GraphConv(hidden_dim, num_classes, weight=True))

        self.dropout = nn.Dropout(p=dropout)

    def forward(self, feat_list, g, type_mask,edge_weight):
        transformed_features = torch.zeros(type_mask.shape[0], self.l_dim)
        for i, fc in enumerate(self.fc_list):
            node_indices = np.where(type_mask == i)[0]
            transformed_features[node_indices] = fc(feat_list[i])
        h = transformed_features
        h = self.dropout(h)
        for i, layers in enumerate(self.hgcn_layers):
            h = self.dropout(h)
            h = layers(g, h,edge_weight=edge_weight)
        return h
